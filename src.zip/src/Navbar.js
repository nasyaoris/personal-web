import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import './navbar.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import {Redirect} from 'react-router'

class Navbar extends React.Component {
  render() {
    return (
    <Router>
     <nav>
      <div className = "container">
      <div class="row">
      <div class="col-sl-3">
      <button type="button" className="btn btn-default" onClick= {() => <Redirect to="/"/> }>Home</button>
      </div>
      <div class="col-sl-3">
      <button type="button" className="btn btn-default" onClick= {() => <Redirect to="/portofolio"/> }>Portofolio</button>
      </div>
      <div class="col-sl-3">
      <button type="button" className="btn btn-default" onClick= {() => <Redirect to="/about"/> }>About me</button>
      </div>
      <div class="col-sl-3"> 
      <button type="button" className="btn btn-default"  onClick= {() => <Redirect to="/experience"/> }>Experience</button>
      </div>
      </div>
      </div> 
     </nav>
     </Router>
     
    );
  }
}

export default Navbar;



